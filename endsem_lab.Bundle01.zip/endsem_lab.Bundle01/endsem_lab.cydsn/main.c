#include "project.h"
#include <stdio.h>

#define TCS34725_ADDRESS  0x29  // 7-bit I2C address of the TCS34725 sensor
#define TCS34725_COMMAND_BIT 0x80

// Register addresses
#define TCS34725_ENABLE    0x00
#define TCS34725_ATIME     0x01
#define TCS34725_CONTROL   0x0F
#define TCS34725_ID        0x12
#define TCS34725_CDATA     0x14

void I2C_WriteByte(uint8_t reg, uint8_t value) {
    uint8_t buffer[2] = {TCS34725_COMMAND_BIT | reg, value};
    I2C_MasterWriteBuf(TCS34725_ADDRESS, buffer, 2, I2C_MODE_COMPLETE_XFER);
    while ((I2C_MasterStatus() & I2C_MSTAT_WR_CMPLT) == 0);
}

uint16_t I2C_ReadWord(uint8_t reg) {
    uint8_t buffer[2];
    uint8_t regAddr = TCS34725_COMMAND_BIT | reg;
    I2C_MasterWriteBuf(TCS34725_ADDRESS, &regAddr, 1, I2C_MODE_COMPLETE_XFER);
    while ((I2C_MasterStatus() & I2C_MSTAT_WR_CMPLT) == 0);
    
    I2C_MasterReadBuf(TCS34725_ADDRESS, buffer, 2, I2C_MODE_COMPLETE_XFER);
    while ((I2C_MasterStatus() & I2C_MSTAT_RD_CMPLT) == 0);
    
    return (buffer[1] << 8) | buffer[0];
}

void TCS34725_Init() {
    I2C_Start();
    CyDelay(3);
    I2C_WriteByte(TCS34725_ENABLE, 0x03);  // Power ON and enable ADC
    I2C_WriteByte(TCS34725_ATIME, 0xFF);   // Maximum integration time
    I2C_WriteByte(TCS34725_CONTROL, 0x01); // Set gain to 4x
}

void Read_RGB_Values(uint16_t *r, uint16_t *g, uint16_t *b) {
    *r = I2C_ReadWord(TCS34725_CDATA + 2);
    *g = I2C_ReadWord(TCS34725_CDATA + 4);
    *b = I2C_ReadWord(TCS34725_CDATA + 6);
}

void Display_RGB_Values(uint16_t r, uint16_t g, uint16_t b) {
    char buffer[16];
    LCD_ClearDisplay();
    
    snprintf(buffer, sizeof(buffer), "R:%u G:%u", r, g);
    LCD_Position(0, 0);
    LCD_PrintString(buffer);
    
    snprintf(buffer, sizeof(buffer), "B:%u", b);
    LCD_Position(1, 0);
    LCD_PrintString(buffer);
}

void USB_Send_RGB_Values(uint16_t r, uint16_t g, uint16_t b) {
    char usbBuffer[64];
    snprintf(usbBuffer, sizeof(usbBuffer), "R:%u, G:%u, B:%u\r\n", r, g, b);
    
    if (USBUART_GetConfiguration()) {
        USBUART_PutString(usbBuffer);
    }
   
    
}

void Control_Pin_By_RGB(uint16_t r, uint16_t g, uint16_t b) {
    // Normalize 16-bit RGB to 8-bit
    uint8_t r8 = (r >> 8) & 0xFF;
    uint8_t g8 = (g >> 8) & 0xFF;
    uint8_t b8 = (b >> 8) & 0xFF;
    
    // Set PWM duty cycle
  //  PWM_Write(r8);
    // PWM_Green_WriteCompare(g8);
    // PWM_Blue_WriteCompare(b8);
}




int main(void) {
    CyGlobalIntEnable;
    I2C_Start();
    LCD_Start();
    USBUART_Start(0, USBUART_5V_OPERATION);
    TCS34725_Init();
    
    uint16_t red, green, blue;
    
    for (;;) {
        if (USBUART_IsConfigurationChanged()) {
            USBUART_CDC_Init();
        }
        
        Read_RGB_Values(&red, &green, &blue);
        Display_RGB_Values(red, green, blue);
        USB_Send_RGB_Values(red, green, blue);
        Control_Pin_By_RGB(red, green, blue);

        
        CyDelay(500);
    }
}